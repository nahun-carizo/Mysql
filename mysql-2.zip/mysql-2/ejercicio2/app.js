// ...

// Rutas

// Agregar cliente
app.post('/clientes', (req, res) => {
    const { nombre, correo, telefono, peso, altura, edad, ciudad } = req.body;
    const query = `
      INSERT INTO Clientes (nombre, correo, telefono, peso, altura, edad, ciudad)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(query, [nombre, correo, telefono, peso, altura, edad, ciudad], (err, result) => {
      if (err) {
        console.error('Error al agregar cliente: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.status(201).send('Cliente agregado exitosamente');
      }
    });
  });
  
  // Listar clientes con peso > 90 y altura > 1.78
  app.get('/clientes/peso-altura', (req, res) => {
    const query = `
      SELECT * FROM Clientes WHERE peso > 90 AND altura > 1.78
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al listar clientes: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.json(results);
      }
    });
  });
  
  // Listar clientes fuera de Mar del Plata con correo Gmail
  app.get('/clientes/no-mar-del-plata-gmail', (req, res) => {
    const query = `
      SELECT * FROM Clientes WHERE ciudad <> 'Mar del Plata' AND correo LIKE '%gmail%'
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al listar clientes: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.json(results);
      }
    });
  });
  
  // Mostrar promedio de alturas de los clientes
  app.get('/clientes/promedio-alturas', (req, res) => {
    const query = `
      SELECT AVG(altura) AS promedio_alturas FROM Clientes
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al calcular el promedio de alturas: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.json(results[0]);
      }
    });
  });
  
  // Mostrar el peso más alto de los clientes
  app.get('/clientes/max-peso', (req, res) => {
    const query = `
      SELECT MAX(peso) AS max_peso FROM Clientes
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al obtener el peso más alto: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.json(results[0]);
      }
    });
  });
  
  // Mostrar el cliente con menor edad
  app.get('/clientes/min-edad', (req, res) => {
    const query = `
      SELECT * FROM Clientes ORDER BY edad ASC LIMIT 1
    `;
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al obtener el cliente con menor edad: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.json(results[0]);
      }
    });
  });
  
  // Exportar la tabla de clientes a un archivo SQL
  app.get('/exportar-sql', (req, res) => {
    const query = 'SELECT * INTO OUTFILE "clientes.sql" FROM Clientes';
    db.query(query, (err) => {
      if (err) {
        console.error('Error al exportar la tabla de clientes: ' + err.stack);
        res.status(500).send('Error interno del servidor');
      } else {
        res.download('clientes.sql');
      }
    });
  });
  
  // ...