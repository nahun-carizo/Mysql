// app.js
const express = require('express');
const app = express();
const db = require('./dbconfig');
const jugadoresController = require('./jugadorescontroller');

const PORT = 3000;

app.use(express.json());
app.use(jugadoresController);

app.listen(PORT, () => {
  console.log(`Servidor Express en http://localhost:${PORT}`);
});