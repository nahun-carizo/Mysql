// jugadoresController.js
const express = require('express');
const router = express.Router();
const db = require('./dbconfig');

// Obtener todos los jugadores
router.get('/jugadores', (req, res) => {
  db.query('SELECT * FROM jugadores', (err, result) => {
    if (err) {
      console.error('Error al obtener jugadores:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.json(result);
    }
  });
});

// Obtener un jugador por ID
router.get('/jugadores/:id', (req, res) => {
  const jugadorId = req.params.id;
  db.query('SELECT * FROM jugadores WHERE id = ?', jugadorId, (err, result) => {
    if (err) {
      console.error('Error al obtener el jugador:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      if (result.length === 0) {
        res.status(404).send('Jugador no encontrado');
      } else {
        res.json(result[0]);
      }
    }
  });
});

// Crear un nuevo jugador
router.post('/jugadores', (req, res) => {
  const nuevoJugador = req.body;
  db.query('INSERT INTO jugadores SET ?', nuevoJugador, (err, result) => {
    if (err) {
      console.error('Error al crear el jugador:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.status(201).send('Jugador creado exitosamente');
    }
  });
});

// Actualizar un jugador por ID
router.put('/jugadores/:id', (req, res) => {
  const jugadorId = req.params.id;
  const datosActualizados = req.body;
  db.query('UPDATE jugadores SET ? WHERE id = ?', [datosActualizados, jugadorId], (err, result) => {
    if (err) {
      console.error('Error al actualizar el jugador:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.status(200).send('Jugador actualizado exitosamente');
    }
  });
});

// Eliminar un jugador por ID
router.delete('/jugadores/:id', (req, res) => {
  const jugadorId = req.params.id;
  db.query('DELETE FROM jugadores WHERE id = ?', jugadorId, (err, result) => {
    if (err) {
      console.error('Error al eliminar el jugador:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.status(200).send('Jugador eliminado exitosamente');
    }
  });
});

module.exports = router;