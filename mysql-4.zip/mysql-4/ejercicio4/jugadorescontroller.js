// jugadoresController.js
const express = require('express');
const fs = require('fs');
const json2csv = require('json2csv');
const router = express.Router();
const db = require('./dbConfig');

// ... (código existente)

// Listar jugadores de Nacionalidad Argentina
router.get('/jugadores/argentina', (req, res) => {
  db.query('SELECT * FROM jugadores WHERE NAC = ?', 'Argentina', (err, result) => {
    if (err) {
      console.error('Error al obtener jugadores argentinos:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.json(result);
    }
  });
});

// Listar jugadores con peso entre 75 y 80 kg
router.get('/jugadores/peso', (req, res) => {
  db.query('SELECT * FROM jugadores WHERE P BETWEEN 75 AND 80', (err, result) => {
    if (err) {
      console.error('Error al obtener jugadores por peso:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.json(result);
    }
  });
});

// Mostrar el jugador más alto
router.get('/jugadores/mas-alto', (req, res) => {
  db.query('SELECT * FROM jugadores ORDER BY Est DESC LIMIT 1', (err, result) => {
    if (err) {
      console.error('Error al obtener el jugador más alto:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      res.json(result);
    }
  });
});

// Exportar la tabla Jugadores a un archivo SQL
router.get('/jugadores/exportar-sql', (req, res) => {
  db.query('SELECT * FROM jugadores', (err, result) => {
    if (err) {
      console.error('Error al obtener jugadores:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      const csvData = json2csv.parse(result, { fields: ['Nombre', 'POS', 'Edad', 'Est', 'P', 'NAC', 'Ap', 'SUB', 'A', 'GA', 'A', 'FC', 'FS', 'TA', 'TR'] });

      fs.writeFile('jugadores_exportados.sql', csvData, 'utf8', (writeErr) => {
        if (writeErr) {
          console.error('Error al exportar la tabla a SQL:', writeErr);
          res.status(500).send('Error interno del servidor');
        } else {
          console.log('Tabla Jugadores exportada exitosamente a jugadores_exportados.sql');
          res.send('Tabla Jugadores exportada exitosamente a jugadores_exportados.sql');
        }
      });
    }
  });
});

module.exports = router;