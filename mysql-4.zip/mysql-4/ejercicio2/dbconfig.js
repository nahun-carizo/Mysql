// dbConfig.js
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'user',
  password: '',
});

connection.connect((err) => {
  if (err) {
    console.error('Error al conectar con MySQL:', err);
  } else {
    console.log('Conexión exitosa con MySQL');
    // Crea la base de datos TP46 si no existe
    connection.query('CREATE DATABASE IF NOT EXISTS TP46', (createErr) => {
      if (createErr) {
        console.error('Error al crear la base de datos TP46:', createErr);
      } else {
        console.log('Base de datos TP46 creada exitosamente');
      }
      connection.end(); // Cierra la conexión después de crear la base de datos
    });
  }
});