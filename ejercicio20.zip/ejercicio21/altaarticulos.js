<form method="post" action="/articulos/alta">
Ingrese descripcion del articulo:
<input type="descripcion" name="descripcion" size="50">
<br>
Ingrese el precio del articulo:
<input type="text" name="precio" size="10">
<br>
<input type="submit" value="Agregar">
</form>